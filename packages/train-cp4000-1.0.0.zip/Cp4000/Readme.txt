Projecto Automotoras Electricas s�rie 4000 - Alfa Pendular: (TEASER) ;)
===========================================================
CP 4000
v0.2 alpha [build 4] modelo para desenvolvimento :\
26-02-2004

to do:
... major overhaul to the models ... 


Thecnical Data:
	Distance Levels
	200m  - 
	1000m - 
        2000m - 1900/2000 poli

==================================================================

Autores e Contactos
Model: S�rgio Miguel Parreira - CP Virtual �2002-2004
smparreira@yahoo.com - webmaster@cpvirtual.org
http://msts.no.sapo.pt - http://www.cpvirtual.org


==================================================================

IMPORTANTE: LER O READMEFIRST.TXT ...

1 Est� autorizado a usar e redestribuir os produtos da CP Virtual gratuitamente.
2 N�o est� autorizado a por os produtos da CP Virtual � venda, revenda, redestribui��o em Cd's disquetes, ou outro suporte com objectivos comerciais e fins lucrativos.
3 Se quiser redistribuir este material, este ficheiro Readme tem de estar sempre inclu�do e contendo sempre o nome dos autores.
4 Ao usar este material, concorda em n�o denegrir a CP Virtual e a CP-Caminhos de Ferro Portugueses, EP publicando imagens que possam causar um impacto negativo na imagem de ambas.
5 Ao usar este material, voc� concorda que o autor n�o � responsavel por qualquer dado que causado � sua vida, ao seu PC e a outro material que possua.
6 � CP pertencem os direitos de autor sobre o seu nome e logotipo. Quaisquer coment�rios ou quest�es relacionadas com os servi�os e produtos cmerciais da CP devem ser dirigidas � mesma atrav�s do seu site www.cp.pt



1 You are hereby granted permission to use and redistribute the CP Virtual products free of charge.
2 You are not granted permission to sell, re-sell, re-distribute for profit or include CP Virtual products on any compilation CD, disk, tape or other distribution media for sale or profit.
3 If you repackage it for redistribution then this Readme and any names must remain intact and included at all times.
4 By using this, you agree in not mis-representing CP Virtual and CP-Caminhos de Ferro Portugueses, EP ( Portuguese National Railway Company), by publishing images that could cause a negative impact on the image of both.
5 By using this model you agree that the author is not liable for any damage it might cause to your life, your PC or your other material.
6 CP owns the copyright to their name and logo. Any comments or questions regarding the real CP trains, their services and products should be addressed directly to CP themselves, at www.cp.pt
