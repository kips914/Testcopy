Vers�o Alfa ... proibida a divulga��o para o exterior ... :P 

 para instalar descomprimam o ficheiro para a pasta do costume ...<gamedir>/Trains/Trainset/ ,se tudo correr bem ter�o um novo direct�rio CP4000 ... 
... se n�o correr bem ... tem que o criar "� unha" :\ 
... o SOUND e o cabview tem ALIASES para a HHP ... acho :|
... metam o ficheiro .con na pasta CONSISTS

S�rgioMP