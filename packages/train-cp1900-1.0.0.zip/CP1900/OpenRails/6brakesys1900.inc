
Comment ( *** CP1900 Braking system *** )
	BrakesEngineBrakeType                                 ( "Air_twin_pipe"  )
	BrakesTrainBrakeType                                  ( "Air_twin_pipe" )
	BrakesEngineControllers						( "Independent, Train, Hand, Dynamic, Blended" )
	BrakeCutsPowerAtBrakeCylinderPressure                 ( 4.8bar )      #( 69.618psi )
	ORTSBrakeRestoresPowerAtBrakePipePressure             ( 5bar )        #( 72.518psi )
	ORTSDoesBrakeCutPower						( 1 )

Comment (*** Compressor, Reservoir and General ***)
	AirBrakesAirCompressorPowerRating 				( 36 )
	AirBrakesAirCompressorWattage 				( 50000 )
	AirBrakesMainMaxAirPressure					( 9bar )      #( 130.534psi verificado em manual de conducao )
  	AirBrakesCompressorRestartPressure				( 8bar )      #( 116.030psi verificado em manual de conducao )
	AirBrakesMainResVolume						( 800l )
	ORTSBrakePipeChargingRate 					( 20.684bar/s ) #( 300---40.611psi )
	ORTSMainResChargingRate 					( 0.047bar/s )  #( 0.682psi/s )
	TrainPipeLeakRate							( 0.005bar/s )  #( 0.0725psi/s valor na CG costuma ser 0,3 bar/mn. Valor na CP deve ser 0,15 bar/min )
	ORTSBrakePipeTimeFactor 					( 0.003 )
  	ORTSBrakeServiceTimeFactor 					( 1.009s )
	ORTSBrakeEmergencyTimeFactor 					( 0.100s )
	ORTSBrakeCutsPowerAtBrakePipePressure                 ( 3.17bar )     #( 46psi )
	ORTSBrakeRestoresPowerAtBrakePipePressure             ( 4.13bar )     #( 60psi )

Comment (*** Automatic Brake valve - Train ***)
	TrainBrakesControllerMaxSystemPressure			( 5.0bar )      #( 72.518psi )
	TrainBrakesControllerMaxReleaseRate				( 3.172bar/s )  #( 46---6.092psi/s )
	TrainBrakesControllerMaxQuickReleaseRate			( 3.172bar/s )  #( 46---6.092psi/s )
	TrainBrakesControllerMaxApplicationRate			( 0.29bar/s )   #( 4.2---12.473psi/s )
	TrainBrakesControllerEmergencyApplicationRate		( 4.137bar/s )  #( 60----24.946psi/s )
	TrainBrakesControllerFullServicePressureDrop		( 1.8bar )      #( 26.107psi )
	TrainBrakesControllerMinPressureReduction 		( 0.4bar )      #( 5.802psi )
	ORTSTrainBrakesControllerMaxOverchargePressure 		( 5.5bar ) 	    #( verificado em manual de conducao )
	ORTSTrainBrakesControllerOverchargeEliminationRate 	( 0.0033bar/s ) Comment (The leakage rate that drops to 5 bar in 150s.)

Comment (*** Independent Brake valve - Engine ***)
	EngineBrakesControllerMaxSystemPressure			( 5.0bar )      #( 72.518psi )
	EngineBrakesControllerMaxReleaseRate			( 0.69bar/s )   #( 10---6.092psi/s )
	EngineBrakesControllerMaxQuickReleaseRate 		( 0.84bar/s )   #( 12.14psi/s )
	EngineBrakesControllerMaxApplicationRate			( 0.69bar/s )   #( 10---12.473psi/s )
	EngineBrakesControllerEmergencyApplicationRate		( 1.72bar/s )   #( 24.946psi/s )
	EngineBrakesControllerFullServicePressureDrop 		( 2.0bar )      #( 26.107psi )
	EngineBrakesControllerMinPressureReduction		( 0.4bar )      #( 5.802psi )

Comment ( == Dynamic Brake == )
	DynamicBrakesMinUsableSpeed				( 10kph )
	DynamicBrakesMaximumEffectiveSpeed			( 42.5kph )
	DynamicBrakesMaximumForce				( 221kN )
	DynamicBrakesResistorCurrentLimit			( 5000 )
	DynamicBrakesCutInSpeed					( 10kph )
	DynamicBrakesMaxAirBrakePressure			( 2.9bar )
	DynamicBrakesFadingSpeed				( 25 )
	DynamicBrakesDelayTimeBeforeEngaging		( 10 )
	DynamicBrakesMaximumSpeedForFadeOut			( 65 )
	DynamicBrakesEffectAtMaximumFadeOut			( 0 )
	DynamicBrakesHigherSpeedCurveExponent		( 1 )
	DynamicBrakesLowerSpeedCurveExponent		( 1 )
	DynamicBrakesNumberOfControllerNotches		( 0 )
	DynamicBrakeHasAutoBailOff 				( 0 )

	ORTSDynamicBlendingOverride				( 1 )
	ORTSDynamicBlendingForceMatch				( 0 )

	ORTSDynamicBrakeForceCurves (
		0.00 (
			0km/h    0kN
			120km/h  0kN
		)
		1.00 (
			0km/h    0kN
			3km/h    65kN
			4km/h    100kN
			5km/h    221kN
			42.5km/h   221kN
			80km/h  150kN
			80km/h  140kN
			95km/h  130kN
			110km/h  120kN
			120km/h  105kN
		)
	)


	