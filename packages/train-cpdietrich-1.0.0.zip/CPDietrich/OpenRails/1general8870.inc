
	Type ( Carriage ) Comment (* Vmax 160kph *)
	Size ( 3.1m 4.05m 24.5m )
Comment( ****************** Coupler Information ******************* )
	Coupling (
		Type ( Chain )
		Spring (
			Stiffness ( 1e4N/m 4.5e6N/m )
			Damping ( 1e6N/m/s 1e6N/m/s )
			Break ( 1200kN 1200kN )
			r0 ( 10cm 10cm )
		)
		CouplingHasRigidConnection ()
		Velocity ( 0.12m/s )
	)
	Buffers (
		Spring (
			Stiffness ( 1e6N/m 5e6N/m )
			Damping ( 1.3e6N/m/s 3.8e6N/m/s )
			r0 ( 0m 1e9 )
		)
		Centre ( 0.5m )
		Radius ( 1m )
		Angle ( 0.5deg )
	)
	
	ORTSFreightAnims (
		WagonEmptyWeight	( 58t )
		LoadingAreaLength	( 23.84 )
		Offset			( 0 0 0 )
		IntakePoint		( 0 6.0 Container)
	)