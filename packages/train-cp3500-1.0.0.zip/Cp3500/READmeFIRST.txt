
 para instalar descomprimam o ficheiro para a pasta do costume ...<gamedir>/Trains/Trainset/ ,se tudo correr bem ter�o um novo direct�rio CP_3500 ... 
... se n�o correr bem ... tem que o criar "� unha" :\ 
... o SOUND e o cabview tem ALIASES para o AcelaHHP 


S�rgioMP