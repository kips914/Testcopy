
    Description (
	"The CP 3500 is a 2 level EMU for Lisbon suburban   "+
	"(c)2002 S�rgio Miguel Parreira / CPVirtual"
    )
    